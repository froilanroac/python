
from functools import reduce


#ejemplo 1:
def do_reduce(a, b):
    print(f"aplicando do_reduce({a}, {b})")
    return a + b

data = range(1, 6)
print(data)
result = reduce(do_reduce, data)
print(f"El resultado es: {result}")

print()
print("Con inicializador")
#ejemplo 2:
data = range(1, 5)
print(data)
result = reduce(do_reduce, data, 99)
print('result: {}'.format(result))