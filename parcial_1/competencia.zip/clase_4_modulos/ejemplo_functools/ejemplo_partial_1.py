from functools import partial

# ejemplo 1:
def power(a, b):
    return a**b

# funciones parciales
pow2 = partial(power, b=2)
pow4 = partial(power, b=4)
pow5 = partial(power, 5)

print(f"power(2, 3) es {power(2, 3)}")
print(f"pow2(4) es {pow2(4)}")
print(f"pow4(3) es {pow4(3)}")
print(f"pow5(2) es {pow5(2)}")

print('Función usada en la función partial pow2:', pow2.func)
print('Keyworks predefinidos por pow2 :', pow2.keywords)
print('Argumentos predefinidos pow5 :', pow5.args)

