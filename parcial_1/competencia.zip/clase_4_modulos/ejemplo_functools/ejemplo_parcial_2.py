from functools import partial


def myfunc(a, b=2):
    """Docstring for myfunc()."""
    print('  myfunc llamada con:', (a, b))


def show_details(name, f, is_partial=False):
    """Show details of a callable object."""
    print(f'función: {name}')
    print(f'objecto: {f}')
    if not is_partial:
        print(f'__name__: {f.__name__}')
    if is_partial:
        print(f'funcion: {f.func}')
        print(f'args: {f.args}')
        print(f'keywords: {f.keywords}' )
    return


show_details('myfunc', myfunc)
myfunc('a', 3)
print()

# Define un valor diferente para ´b', pero requiere
# al llamador suministrar 'a'.
p1 = partial(myfunc, b=4)
show_details(f'partial con el nombrado por default', p1, True)
p1('pasando a')
p1('sobrescribiendo b', b=5)
print()

# Definiendo valores tanto para 'a' y 'b'.
p2 = partial(myfunc, 'default a', b=99)
show_details('partial con defaults', p2, True)
p2()
p2(b='sobrescribiendo b')
print()

print('Insufficient arguments:')
p1()
