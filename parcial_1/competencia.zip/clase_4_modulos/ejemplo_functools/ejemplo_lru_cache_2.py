from functools import lru_cache

@lru_cache()
def expensive(a, b):
    print(f'expensive({a}, {b})')
    return a * b


MAX = 2

print('Primer grupo de llamadas:')
for i in range(MAX):
    for j in range(MAX):
        expensive(i, j)
print(expensive.cache_info())

print('\nSegundo grupo de llamadas:')
for i in range(MAX + 1):
    for j in range(MAX + 1):
        expensive(i, j)
print(expensive.cache_info())

print('\nLimpiando el cache:')
expensive.cache_clear()
print(expensive.cache_info())

print('\nTercer grupo de llamadas:')
for i in range(MAX):
    for j in range(MAX):
        expensive(i, j)
print(expensive.cache_info())