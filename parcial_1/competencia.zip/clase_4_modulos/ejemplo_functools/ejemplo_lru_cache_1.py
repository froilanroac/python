from functools import lru_cache

# ejemplo 1
@lru_cache(maxsize = None)
def factorial(n):
    if n<= 1:
        return 1
    return n * factorial(n-1)
print([factorial(n) for n in range(7)])
print(factorial.cache_info())