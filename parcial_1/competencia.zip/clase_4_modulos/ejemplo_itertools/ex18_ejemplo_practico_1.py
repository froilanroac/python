import itertools as it
# Se tiene tres billetes de 20$, cinco de 10$, dos de 5$ y cinco de 1$.
# ¿De cuántas maneras se pueden agrupar para entregar 100$?

billetes = [20, 20, 20, 10, 10, 10, 10, 10, 5, 5, 1, 1, 1, 1, 1]

# forma 1 (fuerza bruta) # muchas combinaciones repetidas
suma_100 = []
for n in range(1, len(billetes) + 1):
    for combinacion in it.combinations(billetes, n):
        if sum(combinacion) == 100:
            suma_100.append(combinacion)

print(suma_100)

print()
print(80*'-')
print()

# se pueden elimar haciendo un set
set_suma_100 = set(suma_100)
print(set_suma_100)


