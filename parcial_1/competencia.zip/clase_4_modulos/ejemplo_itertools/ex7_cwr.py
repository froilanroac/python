from itertools import combinations_with_replacement as cwr
import itertools as it

#uso:
#combinations_with_replacement(iterable, r)

for i in cwr([1,0], 3): 
    print(i)
