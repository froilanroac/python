import itertools as it

#uso
#tee(iterable, n)

for i in it.tee([1, 2, 3, 4, 5, 6, 7], 3): 
    print(list(i))
    
    # for j in i: 
    #     print(j, end= ' ')
    # print()