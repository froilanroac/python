import itertools as it

#uso:
#count([start=0, step=1])

for i in it.count(5, -3):
    print(i, end=" ")
    if i < -25:
        break
print()