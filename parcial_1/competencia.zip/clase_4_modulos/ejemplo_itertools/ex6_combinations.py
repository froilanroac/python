import itertools as it

#uso:
#combinations(iterable, r)

for i in it.combinations('ABCD',2): 
    print(i)

for i in it.combinations(range(4), 3): 
    print(i)

for i in it.combinations({'a':8, 'b':'casa', 'c':True}.items(), 2): 
    print(i)
