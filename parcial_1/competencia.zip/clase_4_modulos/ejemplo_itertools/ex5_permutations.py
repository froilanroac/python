import itertools as it

#uso:
#permitations(iterable, r=None)

for i in it.permutations('ABCD', 2): #probar con r = 3
    print(i)

for i in it.permutations([1,2,3, 4], 3): #probar con r = 3
    print(i)

for i in it.permutations({'a':8, 'b':'casa', 'c':True}.items()): 
    print(i)