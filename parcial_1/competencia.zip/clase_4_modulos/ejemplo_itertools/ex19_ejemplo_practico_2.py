import itertools as it
import random

# El juego de cartas
# se tiene los valores de las cartas y su pinta
valores = ['A', 'K', 'Q', 'J', '10', '9', '8', '7', '6', '5', '4', '3', '2']
# Corazón = H, Diamante = D, Trébol = C, Pala = S
pintas = ['Cora', 'Diam', 'Tre', 'Pica']

# luego las cartas se formarían asi:
cartas = it.product(pintas, valores)


# si deseamos barajarlas se puede definir una función que devuelva el mazo desordenado
def barajar(mazo):
    mazo = list(mazo)
    random.shuffle(mazo)
    return iter(tuple(mazo))

cartas = barajar(cartas)

# si deseamos partir el mazo, para simular el comienzo de juego
def partir(mazo, n):
    mazo1, mazo2 = it.tee(mazo, 2)
    top = it.islice(mazo1, n)
    bottom = it.islice(mazo2, n, None)
    return it.chain(bottom, top)

cartas = partir(cartas, 26) # se parte el mazo por la mitad

# ahora es hora de repartir las cartas a cada jugador
def repartir(mazo, jugadores=1, cartas_en_mano=5):
    iters = [iter(mazo)] * cartas_en_mano
    return tuple(zip(*(tuple(it.islice(itr, jugadores)) for itr in iters)))

"""  
    El * antes de una lista o una tupla, se usa para "desampaquetar" la lista o tupla
    ver ejemplo ex20
"""


mano1, mano2, mano3, mano4 = repartir(cartas, jugadores= 4)
print('jugador 1: ', mano1)
print('jugador 2: ',mano2)
print('jugador 3: ',mano3)
print('jugador 4: ',mano4)
