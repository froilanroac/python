frutas = ['limón', 'pera', 'melón', 'tomate']
print(frutas[0], frutas[1], frutas[2], frutas[3])

# lo mismo se consigue con:
print(*frutas)
