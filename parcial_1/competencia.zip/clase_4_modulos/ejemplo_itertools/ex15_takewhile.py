import itertools as it

#uso:
#takewhile(predicate, iterable)

for i in it.takewhile(lambda x: x<7, [1, 2, 7, 9, 5, 3, 2, 9]): 
    print(i)