import itertools as it

#uso:
#groupby(iterable, key=None)

for i, j  in it.groupby('AAAAABBCCCCCDDDCCCBBA'):
    print(i, list(j))
    for j in i:
        print(i, list(j))

print(30*'*')

l = [("a", 1), ("a", 2), ("b", 3), ("b", 4)] 
key_f = lambda x: x[0] 
for k, group in it.groupby(l, key_f): 
    print (k + ": " + str(list(group)) )