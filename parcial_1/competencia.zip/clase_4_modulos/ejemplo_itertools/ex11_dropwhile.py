import itertools as it

#uso:
#dropwhile(predicate, iterable)

var = [1, 2, 7, 9, 5, 3, 2, 9]
for i in it.dropwhile(lambda x: x<7, var): 
    print(i, end=", ")

print()
print(var)