import itertools as it

#uso:
#cycle(iterable)

n = 0
for i in it.cycle(['rojo', 'verde', 'azul']):
    print(i)
    n += 1
    if n > 8:
        break

print(30*'*')

n = 0
for i in it.cycle('esta es una cadena de prueba'):
    print(i)
    n += 1
    if n > 50:
        break
