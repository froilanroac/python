import itertools as it

#uso:
#chain(*iterables)

# se pueden pasar n iterables
for i in it.chain('Hola', 'Mundo', 'Adios'): 
    print(i,end=" ")

print()
var = it.chain('Hola', 'Mundo', 'Adios')
print(list(var))

print()

for i in it.chain('Hola', [1,3,5,7,9], (True, False, True)): 
    print(i,end=" ")
print()

#uso:
# chain.from_iterable(iterable)

# se pasa un solo iterable
for i in it.chain.from_iterable(['Hola', 'Mundo', 'Adios']): 
    print(i, end=" ")    

print()
    