import itertools as it

#uso:
#zip_longest(*iterable, fillvalue=None)

for i in it.zip_longest('ABC', '12345'): 
    print(i)

print()
for i in it.zip_longest('ABC', '12345', fillvalue='*'): 
    print(i)

print()
for i in it.zip_longest('ABC', '12345', 'Hola', fillvalue='#'): 
    print(i)