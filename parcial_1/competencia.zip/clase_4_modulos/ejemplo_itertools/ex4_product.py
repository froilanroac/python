import itertools as it

#uso:
#product(*iterables, repeat=1)

for i in it.product([1, 2, 3], [4, 5, 6], [8, 9, 10]):
    print(i)

for n in it.product(['a','b', 'c'], ['x', 'y', 'z'], repeat=2):
    print(n)

for n in it.product(['a','b', 'c'], [0, 1, True]):
    print(n)