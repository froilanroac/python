import itertools as it

#uso
#filterfalse(predicate, iterable)

for i  in it.filterfalse(lambda x: x< 7, [1, 2, 7, 9, 5, 3, 2, 9]):
    print(i, end=', ')

print()