import itertools as it
import operator

#uso:
#accumulate(iterable[, func])

for i in it.accumulate([0, 1, 0, 1, 1, 2, 3, 5]): 
    print(i, end=' - ')

print()

for i in it.accumulate([1, 2, 3, 4, 5], operator.mul): 
    print(i, end=' - ')

print()

for i in it.accumulate([2, 1, 4, 3, 5], max): 
    print(i, end=' - ')

print()

for i in it.accumulate([2, 1, 4, 3, 5], lambda x, y: x + 2*y): 
    print(i, end=' - ')

print()

for i in it.accumulate(['la', ' ', 'nevera', ' ', 'pepito']): 
    print(i, end=' ')
    
print()

for i in it.accumulate([5 ,'a', 3, 'b', 2], operator.mul): 
    print(i, end=' - ')
    
print()