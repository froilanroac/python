import itertools as it
import operator

#uso:
#startmap(function, iterable)

for i in it.starmap(operator.sub, [(2,1), (7,3), (15,19)]): 
    print(i, end="  ")
print()

for i in it.starmap(lambda x,y: x % y, [(4,2), (16,3), (15, 4)]):
    print(i, end="  ")
print()