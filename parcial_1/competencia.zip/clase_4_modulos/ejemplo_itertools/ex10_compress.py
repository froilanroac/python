import itertools as it

#uso:
#compress(data, selectors)

for i in it.compress('ABCDEF', [1, 0, 1, True, 0, ' ']): 
    print(i)
    
for i in it.compress('ABCDEF', lambda x: True): 
    print(i)
