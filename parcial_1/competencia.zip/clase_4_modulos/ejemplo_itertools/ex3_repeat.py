import itertools as it

#uso:
#repeat(elem[, n])

for i in it.repeat(['rojo', 'amarillo'], 3):
    print(i)
    