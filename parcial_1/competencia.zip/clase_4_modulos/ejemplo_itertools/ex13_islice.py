import itertools as it

#uso:
# islice(iterable, start, stop[, step])

for i in it.islice([1, 2, 3, 4, 5], 2): 
    print(i)

print()
for i in it.islice([1, 2, 3, 4, 5], 2, 5): 
    print(i)

print()
for i in it.islice([1, 2, 3, 4, 5], 0, 5, 2): 
    print(i)