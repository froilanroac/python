def main():
    print("esta es una prueba")


if __name__ == "__main__":
    main()
    
    print("otra prueba")