from fibo import fib2
from math import pow

serie = fib2(100)
for i in serie:
    print(i, end=' ')
print()

pow(3, 5)
