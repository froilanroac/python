import fibo as fib      #colocando un alias a todo el módulo
from fibo import fib2 as fibonacci  #colocando un alias a una función del módulo 

#usando el alias del módulo
fib.fib(500)

#usando el alias de una función del módulo
for i in fibonacci(300):
    print(i)