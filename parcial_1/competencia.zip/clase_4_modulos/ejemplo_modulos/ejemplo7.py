import random
import fibo
import math

print(random.randint(10, 100))
# print(dir(random))
print(dir(math))

