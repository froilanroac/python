import fibo

#llamando a una función del módulo fibo
fibo.fib(1000)

serie = fibo.fib2(100)
for i in serie:
    print(i, end=' ')
print()

print(fibo.__name__)

