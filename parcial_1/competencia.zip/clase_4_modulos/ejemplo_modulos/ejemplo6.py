input = 'entrada'
output = 'salida'

import sound.effects.echo
sound.effects.echo.echofilter(input, output, 0.8, 4)

from sound.effects import echo
echo.echofilter(input, output, 0.8, 4)

from sound.effects.echo import echofilter
echofilter(input, output, 0.8, 4)
