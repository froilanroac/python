def echofilter(input, output, delay=0.5, attn=2):
    print(input, output, delay, attn)