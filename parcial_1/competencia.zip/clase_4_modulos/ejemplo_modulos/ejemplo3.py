from fibo import *

fib(1000)

serie = fib2(500)

serie_par = _fib3(600)